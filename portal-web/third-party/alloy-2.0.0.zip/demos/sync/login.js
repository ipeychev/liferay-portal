window.login = function() {
    window.sites = {};

    setTimeout(function() {
        window.sites['foo'] = 'New content...';
        window.app.navigate('preferences.html');
    }, 100);
};