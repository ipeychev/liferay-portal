AUI Form Validator
========

@VERSION@
------

	* #AUI-965 Fixed issue with select box items and displaying error messages