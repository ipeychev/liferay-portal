﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'eu', {
	button: 'Testu Arrunta bezala Itsatsi',
	title: 'Testu Arrunta bezala Itsatsi'
});
