﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'hi', {
	button: 'पेस्ट (सादा टॅक्स्ट)',
	title: 'पेस्ट (सादा टॅक्स्ट)'
});
