﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'ug', {
	button: 'پىچىمى يوق تېكىست سۈپىتىدە چاپلا',
	title: 'پىچىمى يوق تېكىست سۈپىتىدە چاپلا'
});
