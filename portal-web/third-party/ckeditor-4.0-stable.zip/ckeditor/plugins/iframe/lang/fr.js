﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'fr', {
	border: 'Afficher une bordure de la IFrame',
	noUrl: 'Veuillez entrer l\'adresse du lien de la IFrame',
	scrolling: 'Permettre à la barre de défilement',
	title: 'Propriétés de la IFrame',
	toolbar: 'IFrame'
});
