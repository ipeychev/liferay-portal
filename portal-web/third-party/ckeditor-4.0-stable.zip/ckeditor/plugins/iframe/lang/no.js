﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'no', {
	border: 'Viss ramme rundt iframe',
	noUrl: 'Vennligst skriv inn URL for iframe',
	scrolling: 'Aktiver scrollefelt',
	title: 'Egenskaper for IFrame',
	toolbar: 'IFrame'
});
