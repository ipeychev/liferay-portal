﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'vi', {
	copy: 'Bản quyền &copy; $1. Giữ toàn quyền.',
	dlgTitle: 'Thông tin về CKEditor',
	help: 'Kiểm tra $1 để được giúp đỡ.',
	moreInfo: 'Vui lòng ghé thăm trang web của chúng tôi để có thông tin về giấy phép:',
	title: 'Thông tin về CKEditor',
	userGuide: 'Hướng dẫn sử dụng CKEditor'
});
