﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'eu', {
	copy: 'Copyright &copy; $1. Eskubide guztiak erreserbaturik.',
	dlgTitle: 'CKEditor(r)i buruz',
	help: 'Check $1 for help.', // MISSING
	moreInfo: 'Lizentziari buruzko informazioa gure webgunean:',
	title: 'CKEditor(r)i buruz',
	userGuide: 'CKEditor User\'s Guide'
});
