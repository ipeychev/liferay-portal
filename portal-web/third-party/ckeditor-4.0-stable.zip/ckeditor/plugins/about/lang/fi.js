﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'fi', {
	copy: 'Copyright &copy; $1. Kaikki oikeuden pidätetään.',
	dlgTitle: 'Tietoa CKEditorista',
	help: 'Katso ohjeet: $1.',
	moreInfo: 'Lisenssitiedot löytyvät kotisivuiltamme:',
	title: 'Tietoa CKEditorista',
	userGuide: 'CKEditorin käyttäjäopas'
});
