﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'eo', {
	copy: 'Copyright &copy; $1. Ĉiuj rajtoj rezervitaj.',
	dlgTitle: 'Pri CKEditor',
	help: 'Kontroli $1 por helpo.',
	moreInfo: 'Por informoj pri licenco, bonvolu viziti nian retpaĝaron:',
	title: 'Pri CKEditor',
	userGuide: 'CKEditor Uzindikoj'
});
