﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'en-au', {
	options: 'Special Character Options', // MISSING
	title: 'Select Special Character',
	toolbar: 'Insert Special Character'
});
