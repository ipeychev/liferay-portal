﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'en-ca', {
	options: 'Special Character Options', // MISSING
	title: 'Select Special Character',
	toolbar: 'Insert Special Character'
});
