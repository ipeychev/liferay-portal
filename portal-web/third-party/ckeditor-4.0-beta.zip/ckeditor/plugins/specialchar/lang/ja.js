﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'ja', {
	options: '特殊文字オプション',
	title: '特殊文字選択',
	toolbar: '特殊文字挿入'
});
