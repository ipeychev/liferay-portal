﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'bn', {
	options: 'Special Character Options', // MISSING
	title: 'বিশেষ ক্যারেক্টার বাছাই কর',
	toolbar: 'বিশেষ অক্ষর যুক্ত কর'
});
