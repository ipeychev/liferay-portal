﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'sl', {
	copy: 'Copyright &copy; $1. Vse pravice pridržane.',
	dlgTitle: 'O programu CKEditor',
	help: 'Check $1 for help.', // MISSING
	moreInfo: 'Za informacijo o licenci prostim obiščite našo spletno stran:',
	title: 'O programu CKEditor',
	userGuide: 'CKEditor User\'s Guide' // MISSING
});
