;(function() {
    'use strict';

    /**
     * Add Debounce plugin to CKEditor
     */

    CKEDITOR.plugins.add(
        'debounce',
        {
            init: function(editor) {
                CKEDITOR.tools.debounce = this.debounce;
            },

            debounce: function(callback, timeout, context, args) {
                var callFn,
                    debounceHandle;

                callFn = function() {
                    var callContext,
                        calArgs;

                    callContext = context || this;
                    calArgs = args || arguments;

                    clearTimeout(debounceHandle);

                    debounceHandle = setTimeout(function() {
                        callback.apply(callContext, calArgs);
                    }, timeout);
                };

                callFn.cancel = function() {
                    clearTimeout(debounceHandle);
                };

                return callFn;
            }
        }
    );
}());
;(function() {
    'use strict';

    /**
     * Link utilities
     */

    function Link(editor) {
        this._editor = editor;
    }

    Link.prototype = {
        constructor: Link,

        create: function(URI, attrs) {
            var linkAttrs,
                range,
                selection,
                style,
                text;

            selection = this._editor.getSelection();

            range = selection.getRanges()[0];

            if (range.collapsed) {
                text = new CKEDITOR.dom.text(URI, this._editor.document);
                range.insertNode(text);
                range.selectNodeContents(text);
            }

            linkAttrs = CKEDITOR.tools.merge({
                'data-cke-saved-href': URI,
                href: URI
            }, attrs);

            style = new CKEDITOR.style({
                attributes: linkAttrs,
                element: 'a'
            });

            style.type = CKEDITOR.STYLE_INLINE;
            style.applyToRange(range, this._editor);
            range.select();
        },

        getFromSelection: function() {
            var range,
                selection,
                selectedElement;

            selection = this._editor.getSelection();

            selectedElement = selection.getSelectedElement();

            if (selectedElement && selectedElement.is('a')) {
                return selectedElement;
            }

            range = selection.getRanges()[0];

            if (range) {
                range.shrink(CKEDITOR.SHRINK_TEXT);

                return this._editor.elementPath(range.getCommonAncestor()).contains('a', 1);
            }

            return null;
        },

        remove: function(link) {
            var style;

            if (link) {
                link.remove(this._editor);
            }
            else {
                style = link || new CKEDITOR.style({
                    alwaysRemoveElement: 1,
                    element: 'a',
                    type: CKEDITOR.STYLE_INLINE
                });

                this._editor.removeStyle(style);
            }
        },

        update: function(URI, link) {
            var style;

            style = link || this.getFromSelection();

            style.setAttributes({
                'data-cke-saved-href': URI,
                href: URI
            });
        }
    };

    CKEDITOR.plugins.add(
        'linktools',
        {
            init: function(editor) {
                CKEDITOR.tools.Link = new Link(editor);
            }
        }
    );
}());
;(function() {
    'use strict';

    CKEDITOR.SELECTION_TOP_TO_BOTTOM = 0;
    CKEDITOR.SELECTION_BOTTOM_TO_TOP = 1;

    function SelectionRegion() {}

    SelectionRegion.prototype = {
        createSelectionFromPoint: function(x, y) {
            this.createSelectionFromRange(x, y, x, y);
        },

        createSelectionFromRange: function(startX, startY, endX, endY) {
            var editor,
                end,
                endContainer,
                endOffset,
                endRange,
                range,
                selection,
                start,
                startContainer,
                startOffset;

            editor = this.editor;

            if (typeof document.caretPositionFromPoint == 'function') {
                start = document.caretPositionFromPoint(startX, startY);
                end = document.caretPositionFromPoint(endX, endY);

                startContainer = start.offsetNode;
                endContainer = end.offsetNode;

                startOffset = start.offset;
                endOffset = end.offset;

                range = this.createRange();
            }
            else if (typeof document.caretRangeFromPoint == 'function') {
                start = document.caretRangeFromPoint(startX, startY);
                end = document.caretRangeFromPoint(endX, endY);

                startContainer = start.startContainer;
                endContainer = end.startContainer;

                startOffset = start.startOffset;
                endOffset = end.startOffset;

                range = this.createRange();
            }

            if (range && document.getSelection) {
                range.setStart(new CKEDITOR.dom.node(startContainer), startOffset);
                range.setEnd(new CKEDITOR.dom.node(endContainer), endOffset);

                this.getSelection().selectRanges([range]);
            }
            else if (typeof document.body.createTextRange == 'function') {
                selection = this.getSelection();

                selection.unlock();

                range = document.body.createTextRange();
                range.moveToPoint(startX, startY);

                endRange = range.duplicate();
                endRange.moveToPoint(endX, endY);

                range.setEndPoint('EndToEnd', endRange);
                range.select();

                this.getSelection().lock();
            }
        },

        getCaretRegion: function() {
            var bookmarkNodeEl,
                bookmarks,
                docScrollX,
                docScrollXY,
                docScrollY,
                region,
                selection;

            selection = this.getSelection();

            bookmarks = selection.createBookmarks();
            bookmarkNodeEl = bookmarks[0].startNode.$;

            bookmarkNodeEl.style.display = 'inline-block';

            region = new CKEDITOR.dom.element(bookmarkNodeEl).getClientRect();

            bookmarkNodeEl.parentNode.removeChild(bookmarkNodeEl);

            docScrollXY = this._getDocScrollXY();
            docScrollX = docScrollXY[0];
            docScrollY = docScrollXY[1];

            return {
                bottom: docScrollY + region.bottom,
                left: docScrollX + region.left,
                right: docScrollX + region.right,
                top: docScrollY + region.top
            };
        },

        getSelectionData: function() {
            var result,
                selection;

            selection = this.getSelection();

            result = {
                element: selection.getSelectedElement(),
                text: selection.getSelectedText()
            };

            result.region = this.getSelectionRegion(selection);

            return result;
        },

        getSelectionRegion: function() {
            var direction,
                region;

            direction = CKEDITOR.SELECTION_TOP_TO_BOTTOM;

            region = this.getClientRectsRegion();

            region.direction = this._getSelectionDirection();

            region.height = region.bottom - region.top;
            region.width = region.right - region.left;

            return region;
        },

        isSelectionEmpty: function() {
            var ranges,
                selection = this.getSelection();

            return (selection.getType() === CKEDITOR.SELECTION_NONE) ||
                ((ranges = selection.getRanges()) && ranges.length === 1 && ranges[0].collapsed);
        },

        getClientRectsRegion: function() {
            var bottom,
                clientRects,
                docScrollX,
                docScrollXY,
                docScrollY,
                endRect,
                i,
                item,
                left,
                length,
                nativeSelection,
                range,
                rangeCount,
                region,
                right,
                selection,
                startRect,
                top;

            selection = this.getSelection();
            nativeSelection = selection.getNative();

            if (nativeSelection.createRange) {
                range = nativeSelection.createRange();
                clientRects = range.getClientRects();
            }
            else {
                rangeCount = nativeSelection.rangeCount;
                clientRects = (nativeSelection.rangeCount > 0) ? nativeSelection.getRangeAt(0).getClientRects() : [];
            }

            bottom = 0;
            left = Infinity;
            right = -Infinity;
            top = Infinity;

            if (clientRects.length === 0) {
                region = this.getCaretRegion();
            }
            else {
                for (i = 0, length = clientRects.length; i < length; i++) {
                    item = clientRects[i];

                    if (item.left < left) {
                        left = item.left;
                    }

                    if (item.right > right) {
                        right = item.right;
                    }

                    if (item.top < top) {
                        top = item.top;
                    }

                    if (item.bottom > bottom) {
                        bottom = item.bottom;
                    }
                }

                docScrollXY = this._getDocScrollXY();
                docScrollX = docScrollXY[0];
                docScrollY = docScrollXY[1];

                region = {
                    bottom: docScrollY + bottom,
                    left: docScrollX + left,
                    right: docScrollX + right,
                    top: docScrollY + top
                };

                if (clientRects.length) {
                    endRect = clientRects[clientRects.length - 1];
                    startRect = clientRects[0];

                    region.endRect = {
                        bottom: docScrollY + endRect.bottom,
                        height: endRect.height,
                        left: docScrollX + endRect.left,
                        right: docScrollX + endRect.right,
                        top: docScrollY + endRect.top,
                        width: endRect.width
                    };

                    region.startRect = {
                        bottom: docScrollY + startRect.bottom,
                        height: startRect.height,
                        left: docScrollX + startRect.left,
                        right: docScrollX + startRect.right,
                        top: docScrollY + startRect.top,
                        width: startRect.width
                    };
                }
            }

            return region;
        },

        _getDocScrollXY: function() {
            var docBody,
                docDefaultView,
                docElement,
                pageXOffset,
                pageYOffset;



            docBody = document.body;
            docDefaultView = document.defaultView;
            docElement = document.documentElement;

            pageXOffset = (docDefaultView) ? docDefaultView.pageXOffset : 0;
            pageYOffset = (docDefaultView) ? docDefaultView.pageYOffset : 0;

            return [
                Math.max(docElement.scrollLeft, docBody.scrollLeft, pageXOffset),
                Math.max(docElement.scrollTop, docBody.scrollTop, pageYOffset)
            ];
        },

        _getSelectionDirection: function() {
            var anchorNode,
                direction,
                nativeSelection,
                position,
                selection;

            selection = this.getSelection();
            nativeSelection = selection.getNative();

            direction = CKEDITOR.SELECTION_TOP_TO_BOTTOM;

            if ((anchorNode = nativeSelection.anchorNode) && anchorNode.compareDocumentPosition) {
                position = anchorNode.compareDocumentPosition(nativeSelection.focusNode);

                if (!position && nativeSelection.anchorOffset > nativeSelection.focusOffset || position === Node.DOCUMENT_POSITION_PRECEDING) {
                    direction = CKEDITOR.SELECTION_BOTTOM_TO_TOP;
                }
            }

            return direction;
        }
    };

    CKEDITOR.plugins.add(
        'selectionregion',
        {
            init: function(editor) {
                var attr,
                    hasOwnProperty;

                hasOwnProperty = Object.prototype.hasOwnProperty;

                for (attr in SelectionRegion.prototype) {
                    if (hasOwnProperty.call(SelectionRegion.prototype, attr) && typeof editor[attr] == 'undefined') {
                        editor[attr] = SelectionRegion.prototype[attr];
                    }
                }
            }
        }
    );
}());
;(function() {
    'use strict';

    /**
     * Add UITools plugin to CKEditor
     */

    CKEDITOR.plugins.add(
        'uitools',
        {
            init: function(editor) {
                CKEDITOR.tools.merge = this.merge;
            },

            merge: function () {
                var i = 0,
                    key,
                    len = arguments.length,
                    obj,
                    result = {};

                for (; i < len; ++i) {
                    obj = arguments[i];

                    for (key in obj) {
                        if (hasOwnProperty.call(obj, key)) {
                            result[key] = obj[key];
                        }
                    }
               }

                return result;
            }
        }
    );
}());
;(function() {
    'use strict';

    CKEDITOR.plugins.add(
        'uicore',
        {
            init: function(editor) {
                var handleUI;

                handleUI = CKEDITOR.tools.debounce(
                    function(event) {
                        if (event.type !== 'keyup' || event.charCode !== 27 || editor.config.allowEsc) {
                            editor.fire('editorInteraction', {
                                nativeEvent: event.data.$,
                                selectionData: editor.getSelectionData()
                            });
                        }
                    },
                    editor.config.uicore ? editor.config.uicore.delay : 50
                );

                editor.on('contentDom', function() {
                    var editable = editor.editable();

                    editable.attachListener(editable, 'mouseup', handleUI);
                    editable.attachListener(editable, 'keyup', handleUI);
                });
            }
        }
    );
}());
;(function() {
    'use strict';

    var isIE = CKEDITOR.env.ie;

    CKEDITOR.plugins.add(
        'dropimages',
        {
            init: function(editor) {
                var editable;

                editable = new CKEDITOR.editable(editor, editor.element.$);

                editable.attachListener(editable, 'dragenter', this._onDragEnter, this, {
                    editor: editor
                });

                editable.attachListener(editable, 'dragover', this._onDragOver, this, {
                    editor: editor
                });

                editable.attachListener(editable, 'drop', this._onDragDrop, this, {
                    editor: editor
                });
            },

            _handleFiles: function(files, editor) {
                var i,
                    imageType,
                    file;

                for (i = 0; i < files.length; i++) {
                    file = files[i];
                    imageType = /image.*/;

                    if (file.type.match(imageType)) {
                        this._processFile(file, editor);
                    }
                }

                return false;
            },

            _onDragEnter: function(event) {
                if (isIE) {
                    this._preventEvent(event);
                }
            },

            _onDragOver: function(event) {
                if (isIE) {
                    this._preventEvent(event);
                }
            },

            _onDragDrop: function(event) {
                var editor,
                    nativeEvent;

                nativeEvent = event.data.$;

                new CKEDITOR.dom.event(nativeEvent).preventDefault();

                editor = event.listenerData.editor;

                event.listenerData.editor.createSelectionFromPoint(nativeEvent.clientX, nativeEvent.clientY);

                this._handleFiles(nativeEvent.dataTransfer.files, editor);
            },

            _preventEvent: function(event) {
                event = new CKEDITOR.dom.event(event.data.$);

                event.preventDefault();
                event.stopPropagation();
            },

            _processFile: function(file, editor) {
                var reader = new FileReader();

                reader.addEventListener('loadend', function() {
                    var bin,
                        el;

                    bin = reader.result;

                    el = CKEDITOR.dom.element.createFromHtml('<img src="' + bin + '">');

                    editor.insertElement(el);

                    CKEDITOR.fire('imagedrop', el);
                });

                reader.readAsDataURL(file);
            }
        }
    );
}());
;(function() {
    'use strict';

    var REGEX_EOL = /(?:\r?\n\s*)+$/;

    CKEDITOR.plugins.add(
        'placeholder',
        {
            init: function(editor) {
                editor.on('focus', this._onFocus, this);
                editor.on('blur', this._onBlur, this);
            },

            _addPlaceholder: function(editor) {
                editor.setData(editor.config.placeholderValue);

                new CKEDITOR.dom.element(editor.element.$).addClass(editor.config.placeholderClass);
            },

            _onBlur: function(event) {
                var editor = event.editor;

                if (editor.getData() === '') {
                    this._addPlaceholder(editor);
                }
            },

            _onFocus: function(event) {
                var config,
                    data,
                    editor,
                    element;

                editor = event.editor;
                config = editor.config;

                data = editor.getData();

                if (!config.placeholderValue) {
                    config.placeholderValue = editor.getData();

                    this._removePlaceholder(editor);
                }
                else if (data === config.placeholderValue) {
                    this._removePlaceholder(editor);
                }
                else {
                    element = document.createElement('div');

                    element.innerHTML = data;

                    data = element.innerText || element.textContent;

                    if (data === config.placeholderValue || data.replace(REGEX_EOL, '') === config.placeholderValue) {
                        this._removePlaceholder(editor);
                    }
                }
            },

            _removePlaceholder: function(editor) {
                editor.setData('');

                new CKEDITOR.dom.element(editor.element.$).removeClass(editor.config.placeholderClass);
            }
        }
    );
}());
YUI.applyConfig({
    groups: {
        AlloyEditor: {
            base: Liferay.AUI.getJavaScriptRootPath() + '/editor/alloyeditor/',
            combine: true,
            comboBase: Liferay.AUI.getComboPath(),
            modules: {
    'button-base': {
        path: 'buttons/button-base.js',
        requires: ['base-build', 'plugin', 'button']
    },

    'button-strong': {
        path: 'buttons/button-strong.js',
        requires: ['button-base']
    },

    'button-em': {
        path: 'buttons/button-em.js',
        requires: ['button-base']
    },

    'button-a': {
        path: 'buttons/button-a.js',
        requires: ['button-base', 'event-valuechange']
    },

    'button-h1': {
        path: 'buttons/button-h1.js',
        requires: ['button-base']
    },

    'button-h2': {
        path: 'buttons/button-h2.js',
        requires: ['button-base']
    },

    'button-u': {
        path: 'buttons/button-underline.js',
        requires: ['button-base']
    },

    'button-image': {
        path: 'buttons/button-image.js',
        requires: ['button-base']
    },

    'button-code': {
        path: 'buttons/button-code.js',
        requires: ['button-base']
    },

    'button-twitter': {
        path: 'buttons/button-twitter.js',
        requires: ['button-base']
    },

    'button-left': {
        path: 'buttons/button-left.js',
        requires: ['button-base']
    },

    'button-right': {
        path: 'buttons/button-right.js',
        requires: ['button-base']
    },

    'toolbar-base': {
        path: 'toolbars/toolbar-base.js',
        requires: ['plugin', 'node-base']
    },

    'toolbar-add': {
        path: 'toolbars/toolbar-add.js',
        requires: ['overlay', 'node-screen', 'widget-base', 'widget-position', 'widget-autohide', 'toolbar-base']
    },

    'toolbar-styles': {
        path: 'toolbars/toolbar-styles.js',
        requires: ['widget-base', 'widget-position', 'widget-autohide', 'toolbar-base']
    },

    'toolbar-image': {
        path: 'toolbars/toolbar-image.js',
        requires: ['dom-screen', 'widget-base', 'widget-position', 'widget-autohide', 'toolbar-base']
    }
},
            root: Liferay.AUI.getJavaScriptRootPath() + '/editor/alloyeditor/'
        }
    }
});
;(function() {
    'use strict';

    YUI.add('linkedittooltip', function (Y) {
        var Lang = Y.Lang,
            Link = CKEDITOR.plugins.UITools.Link,

        LinkEditTooltip = Y.Base.create('linkedittooltip', Y.Widget, [Y.WidgetPosition, Y.WidgetPositionConstrain, Y.WidgetAutohide], {
            initializer: function() {
                this._eventHandles = [];
            },

            destructor: function() {
                (new Y.EventHandle(this._eventHandles)).detach();

                this._bbMouseEnterHandle.detach();
                this._bbMouseLeaveHandle.detach();
            },

            renderUI: function() {
                var content;

                content = Y.Node.create(this.TPL_CONTENT);

                this._btnGo = new Y.Button({
                    srcNode: content.one('.go-link'),
                    render: content.one('.link-remove-contaner')
                });

                this._btnRemove = new Y.Button({
                    srcNode: content.one('.remove-link'),
                    render: content.one('.link-remove-contaner')
                });

                this._linkPreview = content.one('.link-preview');

                this._linkPreview.on('click', this._onLinkClick, this);

                this.get('contentBox').appendChild(content);
            },

            bindUI: function() {
                var editor;

                this._bindBBMouseEnter();

                this._btnGo.on('click', this._onBtnGoClick, this);
                this._btnRemove.on('click', this._onBtnRemoveClick, this);

                this._linkPreview.on('keypress', this._onLinkPreviewKeyPress, this);

                this.on('visibleChange', this._onVisibleChange, this);

                editor = this.get('editor');

                this._eventHandles.push(
                    Y.one(editor.element.$).delegate('mouseenter', this._onLinkMouseEnter, 'a[href]:not([data-cke-default-link])', this, editor)
                );

                this.get('boundingBox').on('clickoutside', this._onClickOutside, this);
            },

            _bindBBMouseLeave: function() {
                var boundingBox;

                boundingBox = this.get('boundingBox');

                this._bbMouseLeaveHandle = boundingBox.once('mouseleave', this._onBBMouseLeave, this);
            },

            _bindBBMouseEnter: function() {
                var boundingBox;

                boundingBox = this.get('boundingBox');

                this._bbMouseEnterHandle = boundingBox.on('mouseenter', this._onBBMouseEnter, this);
            },

            _attachHiddenHandle: function() {
                var instance = this;

                this._hideHandle = setTimeout(
                    function() {
                        instance.hide();
                    },
                    this.get('hideDelay')
                );
            },

            _getXY: function(x, y, link) {
                var gutter,
                    i,
                    line,
                    lineHeight,
                    lines,
                    region;

                lineHeight = parseInt(link.getComputedStyle('lineHeight'), 10);

                gutter = this.get('gutter');

                region = link.get('region');

                gutter = gutter.top;

                if (Lang.isNumber(lineHeight)) {
                    line = 1;

                    lines =  Math.ceil((region.bottom - region.top) / lineHeight);

                    for (i = 1; i <= lines; i++) {
                        if (y < region.top + lineHeight * i) {
                            break;
                        }

                        ++line;
                    }

                    y = region.top + line * lineHeight + gutter;
                }
                else {
                    y = region.bottom + gutter;
                }

                return [x, y];
            },

            _onBBMouseEnter: function() {
                clearTimeout(this._hideHandle);

                this._bindBBMouseLeave();
            },

            _onBBMouseLeave: function() {
                clearTimeout(this._hideHandle);

                this._attachHiddenHandle();
            },

            _onBtnGoClick: function() {
                Y.config.win.open(this._linkPreview.get('innerHTML'));
            },

            _onClickOutside: function() {
                this.hide();
            },

            _onBtnRemoveClick: function() {
                Link.remove(this._currentLink);

                this.hide();
            },

            _onLinkClick: function(event) {
                event.preventDefault();

                this._onStartLinkEdit();
            },

            _onLinkMouseEnter: function(event) {
                var instance = this,
                    link,
                    linkText,
                    xy;

                if (this._editMode) {
                    return;
                }

                clearTimeout(instance._hideHandle);

                link = event.currentTarget;

                linkText = link.getAttribute('href');

                this._linkPreview.blur();

                this._linkPreview.setAttribute('href', linkText);

                this._linkPreview.set('innerHTML', Y.Escape.html(linkText));

                this._linkPreview.removeClass('link-preview-focused');

                instance.show();

                xy = instance._getXY(event.pageX, event.pageY, link);

                instance.set('xy', xy);

                this._currentLink = new CKEDITOR.dom.element(link.getDOMNode());

                link.once('mouseleave', function() {
                    clearTimeout(instance._hideHandle);

                    instance._attachHiddenHandle();
                });
            },

            _onLinkPreviewKeyPress: function(event) {
                if (event.charCode === 13) {
                    Link.update(this._linkPreview.get('innerHTML'), this._currentLink);

                    this.hide();
                }
            },

            _onStartLinkEdit: function() {
                this._editMode = true;

                clearTimeout(this._hideHandle);

                this._bbMouseLeaveHandle.detach();

                this._linkPreview.addClass('link-preview-focused');
            },

            _onVisibleChange: function(event) {
                if (!event.newVal) {
                    this._editMode = false;
                }
            },

            TPL_CONTENT:
                '<div class="pull-left link-container">' +
                    '<a contenteditable="true" class="link-preview"></a>' +
                '</div>' +
                '<div class="pull-left btn-group link-go-contaner">' +
                    '<button class="btn go-link"><i class="alloy-editor-icon-share"></i></button>' +
                '</div>' +
                '<div class="pull-left btn-group link-remove-contaner">' +
                    '<button class="btn remove-link"><i class="alloy-editor-icon-remove"></i></button>' +
                '</div>'
        }, {
            ATTRS: {
                constrain: {
                    validator: Lang.isBoolean,
                    value: true
                },

                editor: {
                    validator: Y.Lang.isObject
                },

                gutter: {
                    validator: Lang.isObject,
                    value: {
                        top: 0,
                        left: 0
                    }
                },

                hideDelay: {
                    validator: Lang.isNumber,
                    value: 2000
                }
            }
        });

        Y.LinkEditTooltip = LinkEditTooltip;

    },'', {
        requires: ['button', 'dom-screen', 'escape', 'event-outside', 'node-event-delegate', 'event-mouseenter', 'widget-base', 'widget-position', 'widget-position-constrain', 'widget-autohide']
    });

    CKEDITOR.plugins.add(
        'linkedittooltip',
        {
            init: function(editor) {
                YUI().use('linkedittooltip', function(Y) {
                    var config,
                        tooltip;

                    config = Y.merge({
                        editor: editor,
                        visible: false
                    }, editor.config.linkedittooltip);

                    tooltip = new Y.LinkEditTooltip(config).render();
                });
            }
        }
    );
}());
;(function() {
    'use strict';

    YUI.add('linktooltip', function (Y) {
        var Lang = Y.Lang,

        LinkTooltip = Y.Base.create('linktooltip', Y.Widget, [Y.WidgetPosition, Y.WidgetPositionConstrain, Y.WidgetAutohide], {
            initializer: function() {
                this._eventHandles = [];
            },

            destructor: function() {
                (new Y.EventHandle(this._eventHandles)).detach();
            },

            renderUI: function() {
                var content;

                content = Y.Node.create(this.TPL_CONTENT);

                this.get('contentBox').appendChild(content);

                this._linkPreview = content.one('.link-preview');
            },

            bindUI: function() {
                var editor;

                this._bindBBMouseEnter();

                editor = this.get('editor');

                this._eventHandles.push(
                    Y.one(editor.element.$).delegate('mouseenter', this._onLinkMouseEnter, 'a[href]:not([data-cke-default-link])', this, editor)
                );

                this.get('boundingBox').on('clickoutside', this._onClickOutside, this);
            },

            _bindBBMouseLeave: function() {
                var boundingBox;

                boundingBox = this.get('boundingBox');

                this._bbMouseLeaveHandle = boundingBox.once('mouseleave', this._onBBMouseLeave, this);
            },

            _bindBBMouseEnter: function() {
                var boundingBox;

                boundingBox = this.get('boundingBox');

                this._bbMouseEnterHandle = boundingBox.on('mouseenter', this._onBBMouseEnter, this);
            },

            _attachHiddenHandle: function() {
                var instance = this;

                this._hideHandle = setTimeout(
                    function() {
                        instance.hide();
                    },
                    this.get('hideDelay')
                );
            },

            _getXY: function(x, y, link) {
                var gutter,
                    i,
                    line,
                    lineHeight,
                    lines,
                    region;

                lineHeight = parseInt(link.getComputedStyle('lineHeight'), 10);

                gutter = this.get('gutter');

                region = link.get('region');

                gutter = gutter.top;

                if (Lang.isNumber(lineHeight)) {
                    line = 1;

                    lines =  Math.ceil((region.bottom - region.top) / lineHeight);

                    for (i = 1; i <= lines; i++) {
                        if (y < region.top + lineHeight * i) {
                            break;
                        }

                        ++line;
                    }

                    y = region.top + line * lineHeight + gutter;
                }
                else {
                    y = region.bottom + gutter;
                }

                return [x, y];
            },

            _onBBMouseEnter: function() {
                clearTimeout(this._hideHandle);

                this._bindBBMouseLeave();
            },

            _onBBMouseLeave: function() {
                clearTimeout(this._hideHandle);

                this._attachHiddenHandle();
            },

            _onClickOutside: function() {
                this.hide();
            },

            _onLinkMouseEnter: function(event) {
                var instance = this,
                    link,
                    linkText,
                    xy;

                if (this._editMode) {
                    return;
                }

                clearTimeout(instance._hideHandle);

                link = event.currentTarget;

                linkText = link.getAttribute('href');

                this._linkPreview.setAttribute('href', linkText);

                this._linkPreview.set('innerHTML', Y.Escape.html(linkText));

                instance.show();

                xy = instance._getXY(event.pageX, event.pageY, link);

                instance.set('xy', xy);

                link.once('mouseleave', function() {
                    clearTimeout(instance._hideHandle);

                    instance._attachHiddenHandle();
                });
            },

            TPL_CONTENT:
                '<div class="link-container">' +
                    '<span class="alloy-editor-icon-link-container">' +
                        '<i class="alloy-editor-icon-link"></i>' +
                    '</span>' +
                    '<a class="link-preview" target="_blank"></a>' +
                '</div>'
        }, {
            ATTRS: {
                constrain: {
                    validator: Lang.isBoolean,
                    value: true
                },

                editor: {
                    validator: Y.Lang.isObject
                },

                gutter: {
                    validator: Lang.isObject,
                    value: {
                        top: 0,
                        left: 0
                    }
                },

                hideDelay: {
                    validator: Lang.isNumber,
                    value: 2000
                }
            }
        });

        Y.LinkTooltip = LinkTooltip;

    },'', {
        requires: ['dom-screen', 'escape', 'event-outside', 'node-event-delegate', 'event-mouseenter', 'widget-base', 'widget-position', 'widget-position-constrain', 'widget-autohide']
    });

    CKEDITOR.plugins.add(
        'linktooltip',
        {
            init: function(editor) {
                YUI().use('linktooltip', function(Y) {
                    var config,
                        tooltip;

                    config = Y.merge({
                        editor: editor,
                        visible: false
                    }, editor.config.linktooltip);

                    tooltip = new Y.LinkTooltip(config).render();
                });
            }
        }
    );
}());
;(function() {
    'use strict';

    var hasOwnProperty = Object.prototype.hasOwnProperty;

    CKEDITOR.plugins.add(
        'uiloader',
        {
        	init: function(editor) {
	        	var instance = this,
	        		modules;

	        	modules = ['node-base'].concat(this._getModules(editor));

	            YUI().use(
	                modules,
	                function(Y) {
	                	instance._createToolbars(Y, editor);
	                }
	            );
        	},

	        _createToolbars: function(Y, editor) {
	            var defaultConfig,
	                i,
	                toolbarsConfig,
	                UITools = CKEDITOR.plugins.UITools;

	            editor.config.toolbarsInstances = {};

	            defaultConfig = {
	                editor: editor,
	                render: true,
	                visible: false
	            };

	            toolbarsConfig = editor.config.toolbars;

	            for (i in toolbarsConfig) {
	                if (hasOwnProperty.call(toolbarsConfig, i)) {
	                    if (CKEDITOR.tools.isArray(toolbarsConfig[i])) {
	                        editor.config.toolbars[i] = new Y[this._getToolbarName(i)](
	                            Y.merge(defaultConfig, {
	                                buttons: toolbarsConfig[i]
	                            })
	                        );
	                    }
	                    else if(toolbarsConfig[i]) {
	                        editor.config.toolbars[i] = new Y[this._getToolbarName(i)](
	                            Y.merge(defaultConfig, toolbarsConfig[i])
	                        );
	                    }
	                }
	            }
	        },

	        _getModules: function(editor) {
	            var i,
	                j,
	                modules,
	                toolbarsConfig;

	            modules = [];

	            toolbarsConfig = editor.config.toolbars;

	            for (i in toolbarsConfig) {
	                if (hasOwnProperty.call(toolbarsConfig, i)) {
	                    modules.push('toolbar-' + i); // put toolbar module

	                    if (CKEDITOR.tools.isArray(toolbarsConfig[i])) {
	                        for (j = toolbarsConfig[i].length - 1; j >= 0; j--) { // put button modules
	                            modules.push('button-' + toolbarsConfig[i][j]);
	                        }
	                    }
	                    else if (toolbarsConfig[i]) {
	                        for (j = toolbarsConfig[i].buttons.length - 1; j >= 0; j--) { // put button modules
	                            modules.push('button-' + toolbarsConfig[i].buttons[j]);
	                        }
	                    }
	                }
	            }

	            return modules;
	        },

	        _getToolbarName: function(name) {
	            return 'Toolbar' + name.substring(0, 1).toUpperCase() + name.substring(1);
	        }
		}
	);
}());